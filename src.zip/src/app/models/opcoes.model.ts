export const CONTAS = [
  'Itau',
  'Nuconta',
  'Bradesco',
  'Banco do Brasil',
  'Caixa',
  'Santander',
  'Carteira',
];

export const TAGS = [
  'Salário',
  'Receita',
  'Despesa',
  'Transferência',
  'Mecado',
  'Transporte',
  'Saúde',
  'Outros',
];

export const CATEGORIAS_RECEITA = ['Salário', 'Investimentos', 'Freelance', 'Outros'];

export const CATEGORIAS_DESPESA = [
  'Alimentação',
  'Educação',
  'Lazer',
  'Mercado',
  'Moradia / Casa',
  'Saúde',
  'Transporte',
  'Viagens',
  'Pai',
  'Outros',
];
