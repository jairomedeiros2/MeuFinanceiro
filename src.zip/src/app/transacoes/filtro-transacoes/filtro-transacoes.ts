import { TransacoesFilter } from './../../models/filter.model';
import { TransacaoService } from './../../services/transacao';
import { Transacoes } from './../transacoes';
import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CONTAS, TAGS } from '../../models/opcoes.model';

@Component({
  selector: 'app-filtro-transacoes',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './filtro-transacoes.html',
  styleUrls: ['./filtro-transacoes.scss'],
})
export class FiltroTransacoes {
  private transacaoService = inject(TransacaoService);
  public svc = inject(TransacaoService);
  salvarPersonalizado: boolean = true;
  dropdownContasAberto: boolean = false;
  dropdownTagsAberto: boolean = false;
  dropdownTipoAberto: boolean = false;
  dropdownSituacaoAberto: boolean = false;

  readonly contasDisponiveis = CONTAS;
  readonly tagsDisponiveis = TAGS;

  filtros: TransacoesFilter = {
    contas: [] as string[],
    tag: '',
    lancamentoEfetivado: null,
    tipo: '',
    dataInicio: this.transacaoService.filtrosAtivos().dataInicio,
    dataFim: this.transacaoService.filtrosAtivos().dataFim,
  };

  ngOnInit(): void {
    const filtrosSelecionados = this.svc.filtrosAtivos();
    // filtrosSelecionados.dataInicio =  '2026-10-01';
    // filtrosSelecionados.dataFim = '2026-10-31';
    // this.filtros.dataInicio = filtrosSelecionados.dataInicio;
    // this.filtros.dataFim = filtrosSelecionados.dataFim;
    if (filtrosSelecionados) {
      const contasIniciais = Array.isArray(filtrosSelecionados.contas)
        ? filtrosSelecionados.contas
        : filtrosSelecionados.contas
          ? [filtrosSelecionados.contas]
          : [];

      this.filtros.contas = [...contasIniciais];
    }
  }

  alterarDropdown(tipo: string): void {
    console.log('alterarDropdown:', tipo);
    // this.dropdownContasAberto = !this.dropdownContasAberto;
    if (tipo == 'contas') this.dropdownContasAberto = !this.dropdownContasAberto;
    else if (tipo == 'tag') this.dropdownTagsAberto = !this.dropdownTagsAberto;
    else if (tipo == 'tipo') this.dropdownTipoAberto = !this.dropdownTipoAberto;
    else if (tipo == 'situacao') this.dropdownSituacaoAberto = !this.dropdownSituacaoAberto;
  }

  // Fecha o dropdown ao tirar o ponteiro do mouse
  fecharDropdown(tipo: string): void {
    if (tipo == 'contas') this.dropdownContasAberto = false;
    else if (tipo == 'tag') this.dropdownTagsAberto = false;
    else if (tipo == 'tipo') this.dropdownTipoAberto = false;
    else if (tipo == 'situacao') this.dropdownSituacaoAberto = false;
  }

  alterarSelect(tipo: string, valor: any): void {
    if (tipo === 'contas') {
      const index = this.filtros.contas.indexOf(valor);
      if (index > -1) {
        this.filtros.contas.splice(index, 1);
      } else {
        this.filtros.contas.push(valor);
      }
    } else if (tipo === 'tipo') {
      if (valor) this.filtros.tipo = valor;
      else this.filtros.tipo = '';
    } else if (tipo === 'situacao') {
      if (valor == true || valor == false) this.filtros.lancamentoEfetivado = valor;
      else this.filtros.lancamentoEfetivado = null;
    } else if (tipo === 'tag') {
      if (valor) this.filtros.tag = valor;
      else this.filtros.tag = '';
    }
  }

  removerConta(conta: string, event: Event): void {
    event.stopPropagation();
    this.filtros.contas = this.filtros.contas.filter((c) => c !== conta);
  }

  getCorBanco(nomeConta: string): string {
    if (!nomeConta) return '#5c16ca';
    const c = nomeConta.toLowerCase();
    if (c.includes('itau') || c.includes('itaú')) return '#ec7000';
    if (c.includes('nu') || c.includes('nubank')) return '#820ad1';
    if (c.includes('caixa')) return '#005ca9';
    if (c.includes('bradesco')) return '#cc092f';
    if (c.includes('santander')) return '#ea1d2c';
    return '#5c16ca';
  }

  aplicarFiltro() {
    // this.transacaoService.filtrosAtivos.set({ ...this.filtros });
    console.log('filtrosAtivos: ', this.svc.filtrosAtivos);
    this.svc.filtrosAtivos.set({ ...this.filtros });
    console.log('aplicarFiltro: ', this.filtros);

    // Fecha a modal do Bootstrap
    const modalElement = document.getElementById('modalFiltroTransacoes');
    // console.log('modalElement: ', modalElement);
    if (modalElement) {
      const bootstrap = (window as any).bootstrap;
      const modalInstance = bootstrap.Modal.getInstance(modalElement);
      if (modalInstance) modalInstance.hide();
    }
  }
}
